
export default function Disclaimer() {
  return (
    <p className="text-xs text-gray-500 leading-relaxed">
      * Nutrition and dietary information is provided for educational purposes only and is not a substitute for professional medical advice.
    </p>
  );
}
