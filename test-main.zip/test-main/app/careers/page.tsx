
export const metadata = { title: "Careers" };
export default function Page() {
  return (
    <section className="container-max py-16">
      <h1 className="text-3xl font-bold">Careers</h1>
      <p className="mt-2 text-gray-600">Content coming soon.</p>
    </section>
  );
}
